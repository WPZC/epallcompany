create view yc_device_platform as
  select `yc`.`yc_device_info`.`id`                 AS `id`,
         `yc`.`yc_device_info`.`device_num`         AS `device_num`,
         `yc`.`yc_device_info`.`device_name`        AS `device_name`,
         `yc`.`yc_device_info`.`organization_num`   AS `organization_num`,
         `yc`.`yc_device_info`.`organization_name`  AS `organization_name`,
         `yc`.`yc_device_info`.`to_platform`        AS `to_platform`,
         `yc`.`yc_device_info`.`device_mn`          AS `device_mn`,
         `yc`.`yc_platform_info`.`to_ip`            AS `to_ip`,
         `yc`.`yc_platform_info`.`to_port`          AS `to_port`,
         `yc`.`yc_platform_info`.`to_platform_name` AS `to_platform_name`,
         `yc`.`yc_platform_info`.`agreement_type`   AS `agreement_type`
  from `yc`.`yc_device_info`
         join `yc`.`yc_platform_info`
  where (`yc`.`yc_device_info`.`to_platform` = `yc`.`yc_platform_info`.`to_platform_name`);

