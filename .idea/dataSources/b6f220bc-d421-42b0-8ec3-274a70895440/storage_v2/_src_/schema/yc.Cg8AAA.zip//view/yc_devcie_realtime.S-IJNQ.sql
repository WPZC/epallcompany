create view yc_devcie_realtime as
  select `yc`.`yc_device_info`.`device_num`                AS `device_num`,
         `yc`.`yc_device_info`.`device_name`               AS `device_name`,
         `yc`.`yc_device_info`.`address`                   AS `address`,
         `yc`.`yc_device_info`.`longitude`                 AS `longitude`,
         `yc`.`yc_device_info`.`latitude`                  AS `latitude`,
         `yc`.`yc_realtimeinfo`.`pm25`                     AS `pm25`,
         `yc`.`yc_realtimeinfo`.`pm10`                     AS `pm10`,
         `yc`.`yc_realtimeinfo`.`noise`                    AS `noise`,
         `yc`.`yc_realtimeinfo`.`air_temperature`          AS `air_temperature`,
         `yc`.`yc_realtimeinfo`.`air_humidity`             AS `air_humidity`,
         `yc`.`yc_realtimeinfo`.`wind_speed`               AS `wind_speed`,
         `yc`.`yc_realtimeinfo`.`wind_direction`           AS `wind_direction`,
         `yc`.`yc_realtimeinfo`.`tsp`                      AS `tsp`,
         `yc`.`yc_realtimeinfo`.`oxygen_factor`            AS `oxygen_factor`,
         `yc`.`yc_realtimeinfo`.`atmospheric_pressure`     AS `atmospheric_pressure`,
         `yc`.`yc_realtimeinfo`.`ydi_belong_to_enterprise` AS `ydi_belong_to_enterprise`,
         `yc`.`yc_device_info`.`organization_num`          AS `organization_num`,
         `yc`.`yc_device_info`.`organization_name`         AS `organization_name`,
         `yc`.`yc_device_info`.`id`                        AS `id`,
         `yc`.`yc_realtimeinfo`.`updatetime`               AS `updatetime`
  from (`yc`.`yc_device_info` join `yc`.`yc_realtimeinfo`)
  where (`yc`.`yc_device_info`.`device_num` = `yc`.`yc_realtimeinfo`.`ydi_device_num`);

